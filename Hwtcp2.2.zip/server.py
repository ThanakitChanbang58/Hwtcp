#!/usr/bin/env python

import socket
import os    # input Operating System
import base64

TCP_IP = '127.0.0.1'
TCP_PORT = 5060
BUF_SIZE = 50000

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((TCP_IP, TCP_PORT))
s.listen(1)


conn, addr = s.accept()
print 'Connection address:', addr
myfile = open('2.py', 'wb')
if not os.path.exists("D:\Home work tcp 2.2"+"/image_from_client/"):
    os.makedirs("D:\Home work tcp 2.2"+"/image_from_client/")
with open("D:\Home work tcp 2.2"+"/image_from_client/"+'image.jpg','wb'):     
   while 1:
        data = conn.recv(BUF_SIZE) 
        if not data: break 
        data = base64.b64decode(data) 
        myfile.write(data) 
        print('wait a minite')

        myfile.close() 
        print('colse writing')
        conn.close() 
        print('disconnected')
        break 
